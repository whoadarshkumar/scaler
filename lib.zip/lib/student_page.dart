import 'package:flutter/material.dart';

class StudentPage extends StatefulWidget {
  final String mentor;

  // For demonstration purposes, a simple list of students
  final List<String> allStudents = [
    'Student A',
    'Student B',
    'Student C',
    'Student D',
    'Student E',
    'Student F'
  ];

  StudentPage({required this.mentor});

  @override
  _StudentPageState createState() => _StudentPageState();
}

class _StudentPageState extends State<StudentPage> {
  List<String> assignedStudents = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Students for ${widget.mentor}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Assigned Students:'),
            Column(
              children: assignedStudents
                  .map((student) => ElevatedButton(
                        onPressed: () {
                          // Handle click for assigned student
                          print('Clicked on assigned student: $student');
                        },
                        child: Text('Assigned: $student'),
                      ))
                  .toList(),
            ),
            SizedBox(height: 20),
            Text('Unassigned Students:'),
            Column(
              children: widget.allStudents
                  .where((student) => !assignedStudents.contains(student))
                  .map((student) => ElevatedButton(
                        onPressed: () {
                          // Check if mentor can accommodate more students
                          if (assignedStudents.length < 4) {
                            // Check if the student is not assigned to this mentor
                            if (!assignedStudents.contains(student)) {
                              setState(() {
                                assignedStudents.add(student);
                              });
                            } else {
                              // Student is already assigned to this mentor
                              // Handle this case as needed
                              print(
                                  'Student $student is already assigned to Mentor ${widget.mentor}.');
                            }
                          } else {
                            // Mentor cannot accommodate more students
                            // Handle this case as needed
                            print(
                                'Mentor ${widget.mentor} cannot accommodate more students.');
                          }
                        },
                        child: Text('Unassigned: $student'),
                      ))
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}
