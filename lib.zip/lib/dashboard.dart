import 'package:evaluation_dashboard/models/mentor_model.dart';
import 'package:evaluation_dashboard/models/student_model.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DashboardPage extends StatefulWidget {
  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late List<Mentor> mentors;
  late Mentor selectedMentor;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Evaluation Dashboard'),
        backgroundColor: Colors.blue,
      ),
      body: FutureBuilder<List<Mentor>>(
        // Fetch mentors from Firestore
        future: fetchMentors(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          } else if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          } else {
            mentors = snapshot.data!;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // DropdownButton for mentors
                DropdownButton<Mentor>(
                  value: selectedMentor,
                  onChanged: (Mentor? newValue) {
                    setState(() {
                      selectedMentor = newValue!;
                    });
                  },
                  items: mentors.map((mentor) {
                    return DropdownMenuItem<Mentor>(
                      value: mentor,
                      child: Text(mentor.name),
                    );
                  }).toList(),
                ),
                SizedBox(height: 20),
                // Display assigned students
                Text('Students Assigned under ${selectedMentor.name}:'),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: selectedMentor.studentAssign.length,
                  itemBuilder: (context, index) {
                    return Text(selectedMentor.studentAssign[index]);
                  },
                ),
                SizedBox(height: 20),
                // Display students not assigned under the teacher
                Text('Students Not Assigned under ${selectedMentor.name}:'),
                FutureBuilder<List<Student>>(
                  // Fetch students from Firestore
                  future: fetchStudents(),
                  builder: (context, studentSnapshot) {
                    if (studentSnapshot.connectionState ==
                        ConnectionState.waiting) {
                      return CircularProgressIndicator();
                    } else if (studentSnapshot.hasError) {
                      return Text('Error: ${studentSnapshot.error}');
                    } else {
                      List<Student> allStudents = studentSnapshot.data!;
                      List<Student> unassignedStudents = allStudents
                          .where((student) => !selectedMentor.studentAssign
                              .contains(student.name))
                          .toList();
                      return ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: unassignedStudents.length,
                        itemBuilder: (context, index) {
                          return Text(unassignedStudents[index].name);
                        },
                      );
                    }
                  },
                ),
              ],
            );
          }
        },
      ),
    );
  }

  Future<List<Mentor>> fetchMentors() async {
    // Replace 'your_mentors_collection' with your actual collection name
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('your_mentors_collection')
        .get();
    return querySnapshot.docs.map((doc) {
      return Mentor.fromMap(doc.data() as Map<String, dynamic>);
    }).toList();
  }

  Future<List<Student>> fetchStudents() async {
    // Replace 'your_students_collection' with your actual collection name
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('your_students_collection')
        .get();
    return querySnapshot.docs.map((doc) {
      return Student.fromMap(doc.data() as Map<String, dynamic>);
    }).toList();
  }
}
